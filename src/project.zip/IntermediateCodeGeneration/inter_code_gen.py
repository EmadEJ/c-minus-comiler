# this class is responsible for generating the intermediate code

ICG_OUTPUT_PATH = "./output.txt"

INT_SIZE = 4 #4 Bytes

class ICG:
    def __init__(self):
        self.env = self.Environment()
        self.program_block = self.ProgramBlock()

        self.semantic_stack = []
            # we put strings in the stack. regular numbers (e.g. 100) means direct addressing
            # for immediate numbers we use #. for example #100.
            # we also can write indirect addressing by putting @ behind numbers.

        # list of flags:
        self.force_declare = False
        self.no_push = False
        self.function_scope = False

    def take_action(self, action, input_str = None):
        match action:
            case "ASSIGN":
                # Assigns the value from the top of the stack to the address below it.
                # Example: arg2 = arg1
                top = self.sp()
                arg1 = self.semantic_stack[top]      # Value to assign
                arg2 = self.semantic_stack[top-1]    # Address to assign to
                self.program_block.new_command("ASSIGN", arg1, arg2)
                self.pop(2)
                # The assigned value is pushed back to allow for chained assignments (e.g., x = y = 5).
                self.semantic_stack.append(arg1)

            case "OPERATE":
                # Performs an arithmetic operation.
                top = self.sp()
                arg2 = self.semantic_stack[top]
                symb = self.semantic_stack[top-1]
                arg1 = self.semantic_stack[top-2]
                result_addr = str(self.env.temp_address())

                match symb:
                    case "+":
                        command_type = "ADD"
                    case "-":
                        command_type = "SUB"
                    case "*":
                        command_type = "MULT"
                    case _:
                        raise Exception(f"{symb} was not a operator")

                self.program_block.new_command(command_type, arg1, arg2, result_addr)
                self.pop(3)
                self.semantic_stack.append(result_addr)


            case "PID":
                # Pushes the address of a given identifier (variable) onto the stack.
                address = str(self.env.get_address(input_str))
                if not self.no_push:
                    self.semantic_stack.append(address)

            case "LIST_ACC":
                # Calculates the memory address of an array element (e.g., a[i]).
                top = self.sp()
                index_addr_str = self.semantic_stack[top]   # Address of the index 'i'
                list_addr_str = self.semantic_stack[top-1]   # Base address of the array 'a'
                tmp_addr = str(self.env.temp_address())
                # Calculate offset: tmp <- index * element_size
                self.program_block.new_command("MULT", index_addr_str, f"#{INT_SIZE}", tmp_addr)
                result_addr = str(self.env.temp_address())
                # Calculate final address: result <- base_address + offset
                self.program_block.new_command("ADD",  list_addr_str, tmp_addr, result_addr)
                self.pop(2)
                # Push the final address of the element onto the stack for later use (assignment or reading).
                # The '@' prefix indicates indirect addressing.
                self.semantic_stack.append(f"@{result_addr}")

            case "IMM":
                # Pushes an immediate value (a constant number) onto the stack.
                immediate_str = "#" + input_str
                self.semantic_stack.append(immediate_str)

            case "SYMB":
                # Pushes an operator symbol onto the stack for later processing.
                self.semantic_stack.append(input_str)

            case "COMPARE":
                # Performs a comparison operation.
                top = self.sp()
                arg2 = self.semantic_stack[top]
                symb = self.semantic_stack[top-1]
                arg1 = self.semantic_stack[top-2]
                result_addr = str(self.env.temp_address())

                match symb:
                    case "==":
                        command_type = "EQ"
                    case "<":
                        command_type = "LT"
                    case _:
                        raise Exception(f"{symb} was not a relop")

                self.program_block.new_command(command_type, arg1, arg2, result_addr)
                self.pop(3)
                self.semantic_stack.append(result_addr)

            case "NEG":
                # Negates the value at the top of the stack.
                top = self.sp()
                arg = self.semantic_stack[top]
                result_addr = str(self.env.temp_address())
                self.program_block.new_command("SUB", "#0", arg, result_addr) # Negation by subtracting from zero
                self.pop()
                self.semantic_stack.append(result_addr)


            case "SAVE_TYPE":
                # Saves the current type specifier (e.g., 'int', 'void') for semantic checks.
                self.current_type = input_str

            case "SET_FORCE_DECLARE":
                self.force_declare = True

            case "UNSET_FORCE_DECLARE":
                self.force_declare = False

            case "START_NO_PUSH":
                if not self.function_scope:
                    self.no_push = True

            case "END_NO_PUSH":
                self.no_push = False

            case "ZERO_INIT":
                # In a full compiler, this action initializes a declared variable with 0.
                # This is particularly for local variables within functions.
                pass

            case "VOID_CHECK_THROW":
                # This action would perform a semantic check to ensure a variable is not
                # being declared with type 'void', which is illegal.
                pass

            case "PNUM":
                # Pushes a number literal onto the stack, typically for array size declarations.
                num = f"#{input_str}"
                if not self.no_push:
                    self.semantic_stack.append(num)

            case "DECLARE_ARRAY":
                # Finalizes an array declaration by reserving a contiguous block of memory.
                size_str = self.semantic_stack.pop()  # e.g., '#10'
                size = int(size_str[1:])
                # The array's base address is already on the stack from the #PID action.
                # `new_reference` already allocated space for the first element,
                # so we allocate space for the remaining (size - 1) elements.
                if size > 1:
                    self.env.last_address += (size - 1) * INT_SIZE

            case "POP":
                # Removes the top element from the semantic stack. Used after an expression statement that produces a value that is not used.
                self.pop()

            case "LABEL":
                # Pushes the current program line number to the stack to mark a location for a jump.
                self.semantic_stack.append(self.program_block.get_line_number())

            case "SAVE":
                # Saves the current program line for a future jump instruction and leaves a placeholder.
                self.semantic_stack.append(self.program_block.get_line_number())
                self.program_block.skip_line()

            case "JUMP_BACK":
                # Generates a jump to a return address. In a real compiler, this would be managed
                # on a runtime stack. Here, we simplify by assuming the address is on the semantic stack.
                return_address = self.semantic_stack.pop()
                self.program_block.new_command("JP", f"@{return_address}")

            case "SET_RETURN_VALUE":
                # Moves a value into a conventional location for function return values.
                # Here, we assume a dedicated memory address (e.g., address 0) for this purpose.
                value_to_return = self.semantic_stack.pop()
                self.program_block.new_command("ASSIGN", value_to_return, "0")

            case "WHILE":
                # Completes a while loop by back-patching the conditional jump and adding the loop-back jump.
                save_address = self.semantic_stack.pop()
                condition = self.semantic_stack.pop()
                label_address = self.semantic_stack.pop()
                self.program_block.new_command("JP", label_address)
                # The conditional jump (JPF) will skip the loop body if the condition is false.
                # It jumps to the line immediately after the `JP` command we just added.
                self.program_block.write_command_at(save_address, "JPF", condition, self.program_block.get_line_number())

            case _:
                # This case handles any actions defined in the grammar but not yet implemented.
                pass

    def sp(self):
        return len(self.semantic_stack) - 1
    def pop(self, number=1):
        for i in range(number):
            self.semantic_stack.pop()

    class ProgramBlock:
        def __init__(self):
            self.blocks = []

        def new_command(self, command_type, arg1, arg2=None, arg3=None):
            command = (command_type, arg1, arg2, arg3)
            self.blocks.append(command)
        def write_command_at(self, line_number, command_type, arg1, arg2=None, arg3=None):
            command = (command_type, arg1, arg2, arg3)
            self.blocks[line_number] = command
        def skip_line(self, number=1):
            for i in range(number):
                self.blocks.append(None)
        def get_line_number(self):
            return len(self.blocks)
        def save(self):
            with open(ICG_OUTPUT_PATH, "w", encoding='utf-8') as icg_output_file:
                line_number = 0
                for command in self.blocks:
                    if command is None: # Handle skipped lines
                        line_number +=1
                        continue
                    command_type, arg1, arg2, arg3 = command
                    if arg1 == None:
                        icg_output_file.write(f"{line_number}\t({command_type}, , , )")
                    elif arg2 == None:
                        icg_output_file.write(f"{line_number}\t({command_type}, {arg1}, , )")
                    elif arg3 == None:
                        icg_output_file.write(f"{line_number}\t({command_type}, {arg1}, {arg2}, )")
                    else:
                        icg_output_file.write(f"{line_number}\t({command_type}, {arg1}, {arg2}, {arg3})")
                    icg_output_file.write("\n")
                    line_number += 1



    class Environment:
        # this class stores variable addresses and give new addresses
        def __init__(self):
            self.env = {}
            self.last_address = 100

        def new_reference(self, var_name):
            self.env[var_name] = self.last_address
            self._go_next_address()
            return self.env[var_name]

        def temp_address(self):
            tmpaddr = self.last_address
            self._go_next_address()
            return tmpaddr

        def get_address(self, var_name):
            if var_name not in self.env:
                self.new_reference(var_name)
            return self.env[var_name]

        def _go_next_address(self):
            self.last_address += INT_SIZE
